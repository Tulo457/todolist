import React, { useState } from 'react';
import './App.css';

function App(){
  
    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState('');

    const addTask = () => {
      if (newTask.trim() !== '') {
        setTasks([...tasks, newTask]);
        setNewTask('');
      }
    };

    const removeTask = (index) => {
      const newTasks = [...tasks];
      newTasks.splice(index, 1);
      setTasks(newTasks);
    };

    return (
      <div className="App">
        
        <h1 class="mt-5">Todo List</h1>
        <div>
          <input type="text" class="textInput form-control" value={newTask} onChange={(e) => setNewTask(e.target.value)} placeholder="Add a new task..."/>
          <button type="button" class="btn btn-primary mt-3" onClick={addTask}>Add Task</button>
        </div>
        
        <ul class="container">
          {tasks.map((task, index) => (
            <li key={index}>
              {task}
              <button type="button" class="removeBtn btn btn-danger" onClick={() => removeTask(index)}>Remove</button>
            </li>
          ))}
        
        </ul>
      </div>
    );
}

export default App;
